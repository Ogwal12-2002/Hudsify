package com.hudsify.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
