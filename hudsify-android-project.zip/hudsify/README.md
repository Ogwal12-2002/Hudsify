# Hudsify (Android)
Option A - no PC: create a GitHub repo, upload everything in this folder, open Actions > Build APK > Run workflow, then download "Hudsify-apk" and install app-debug.apk.
Option B - Android Studio: npm install, npx cap sync android, open the android/ folder, Build > Build APK(s).
Or in a terminal: cd android && ./gradlew assembleDebug  (APK: android/app/build/outputs/apk/debug/app-debug.apk)
